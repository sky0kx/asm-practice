calling C from Assembly

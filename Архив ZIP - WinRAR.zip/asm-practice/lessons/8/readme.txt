calling Assembly from C
